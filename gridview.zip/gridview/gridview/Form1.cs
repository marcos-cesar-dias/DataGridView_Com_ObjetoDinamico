﻿using Microsoft.CSharp.RuntimeBinder;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Dynamic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gridview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var obj = new ListaObjetoDinamico<ObjetoDinamico>();

            dynamic pessoa = new ObjetoDinamico();
            pessoa.Nome = "Maria";
            pessoa.Id = 1;
            pessoa.Endereco = "rua";
            
            obj.Add(pessoa);

            pessoa = new ObjetoDinamico();
            pessoa.Nome = "Ana";
            pessoa.Id = 2;
            pessoa.Endereco = "Teste";
            obj.Add(pessoa);

            dataGridView1.AutoGenerateColumns = true;

            dataGridView1.DataSource = obj;

        }
    }

    public class ObjetoDinamico : DynamicObject
    {
        // The inner dictionary.
        Dictionary<string, object> dictionary
            = new Dictionary<string, object>();


        public Dictionary<string, object> List()
        {
            return dictionary;
        }

        // This property returns the number of elements
        // in the inner dictionary.

        public int Count
        {
            get
            {
                return dictionary.Count;
            }
        }


        // If you try to get a value of a property 
        // not defined in the class, this method is called.
        public override bool TryGetMember(
            GetMemberBinder binder, out object result)
        {
            // Converting the property name to lowercase
            // so that property names become case-insensitive.
            string name = binder.Name.ToLower();

            // If the property name is found in a dictionary,
            // set the result parameter to the property value and return true.
            // Otherwise, return false.
            if (dictionary.TryGetValue(name, out result))
                return true;
            else
            {
                result = null;
                return true;
            }

        }

        // If you try to set a value of a property that is
        // not defined in the class, this method is called.
        public override bool TrySetMember(
            SetMemberBinder binder, object value)
        {
            // Converting the property name to lowercase
            // so that property names become case-insensitive.
            dictionary[binder.Name.ToLower()] = value;


            // You can always add a value to a dictionary,
            // so this method always returns true.
            return true;

        }

        public override IEnumerable<string> GetDynamicMemberNames()
        {
            return dictionary.Keys.ToArray();
        }

    }


    public class ListaObjetoDinamico<T> : ObservableCollection<T>, IList, ITypedList
    where T : DynamicObject
    {
        public string GetListName(PropertyDescriptor[] listAccessors)
        {
            return null;
        }

        public PropertyDescriptorCollection GetItemProperties(PropertyDescriptor[] listAccessors)
        {
            var dynamicDescriptors = new PropertyDescriptor[0];
            if (this.Any())
            {
                var firstItem = this[0];

                dynamicDescriptors =
                    firstItem.GetDynamicMemberNames()
                    .Select(p => new DynamicPropertyDescriptor(p))
                    .Cast<PropertyDescriptor>()
                    .ToArray();
            }

            return new PropertyDescriptorCollection(dynamicDescriptors);
        }
    }

    public class DynamicPropertyDescriptor : PropertyDescriptor
    {
        public DynamicPropertyDescriptor(string name)
            : base(name, null)
        {
        }

        public override bool CanResetValue(object component)
        {
            return false;
        }

        public override object GetValue(object component)
        {
            return GetDynamicMember(component, Name);
        }

        public override void ResetValue(object component)
        {
        }

        public override void SetValue(object component, object value)
        {
            SetDynamicMember(component, Name, value);
        }

        public override bool ShouldSerializeValue(object component)
        {
            return false;
        }

        public override Type ComponentType
        {
            get { return typeof(object); }
        }

        public override bool IsReadOnly
        {
            get { return false; }
        }

        public override Type PropertyType
        {
            get { return typeof(object); }
        }

        private static void SetDynamicMember(object obj, string memberName, object value)
        {
            var binder = Binder.SetMember(
                CSharpBinderFlags.None,
                memberName,
                obj.GetType(),
                new[]
                {
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
                });
            var callsite = CallSite<Action<CallSite, object, object>>.Create(binder);
            callsite.Target(callsite, obj, value);
        }

        private static object GetDynamicMember(object obj, string memberName)
        {
            var binder = Binder.GetMember(
                CSharpBinderFlags.None,
                memberName,
                obj.GetType(),
                new[]
                {
                    CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
                });
            var callsite = CallSite<Func<CallSite, object, object>>.Create(binder);
            return callsite.Target(callsite, obj);
        }
    }
}
